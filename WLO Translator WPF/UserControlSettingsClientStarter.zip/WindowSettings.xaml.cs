﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace WLO_Translator_WPF
{
    public partial class WindowSettings : Window
    {
        //private UserControlSettingsGeneral          mUserControlSettingsGeneral;
        //private UserControlSettingsPaths            mUserControlSettingsPaths;
        private UserControlSettingsClientStarter    mUserControlSettingsSleepTimes;
        private UserControl                         mUserControlLastUsed;

        public  bool                                SettingsChangedFlag { get; set; } = false;

        // Old values
        private string  mWLOProgramPathOld;
        private string  mWLOUpdateProgramPathOld;
        private bool    mUseWLOProgramFolderForUpdateProgramOld;
        private int     mSleepLengthShortOld;
        private int     mSleepLengthLongOld;
        private int     mTimeBeforeRetryOld;
        private int     mRetryTimesOld;
        private int     mTimeBetweenClientStartsOld;
        private int     mLengthFromScreenSidesHOld;
        private int     mLengthFromScreenSidesVOld;
        private int     mThemeIndexOld;

        public WindowSettings(string WLOProgramPath, string WLOUpdateProgramPath, bool useWLOProgramFolderForUpdateProgram,
                            int sleepLengthShort, int sleepLengthLong,
                            int timeBeforeRetry, int retryTimes, int timeBetweenClientStarts,
                            int lengthFromScreenSidesH, int lengthFromScreenSidesV)
        {
            InitializeComponent();

            // Store old values to check against if save is necessary
            mWLOProgramPathOld                      = WLOProgramPath;
            mWLOUpdateProgramPathOld                = WLOUpdateProgramPath;
            mUseWLOProgramFolderForUpdateProgramOld = useWLOProgramFolderForUpdateProgram;
            mSleepLengthShortOld                    = sleepLengthShort;
            mSleepLengthLongOld                     = sleepLengthLong;
            mTimeBeforeRetryOld                     = timeBeforeRetry;
            mRetryTimesOld                          = retryTimes;
            mTimeBetweenClientStartsOld             = timeBetweenClientStarts;
            mLengthFromScreenSidesHOld              = lengthFromScreenSidesH;
            mLengthFromScreenSidesVOld              = lengthFromScreenSidesV;
            //mThemeIndexOld                          = ThemeManager.ThemeIndex;

            //mUserControlSettingsGeneral     = new UserControlSettingsGeneral();
            //mUserControlSettingsPaths       = new UserControlSettingsPaths(WLOProgramPath, WLOUpdateProgramPath, useWLOProgramFolderForUpdateProgram);
            mUserControlSettingsSleepTimes  = new UserControlSettingsClientStarter(sleepLengthShort, sleepLengthLong,
                                                                                   timeBeforeRetry, retryTimes, timeBetweenClientStarts,
                                                                                   lengthFromScreenSidesH, lengthFromScreenSidesV);
            //InitializeUserControl(mUserControlSettingsGeneral);
            //InitializeUserControl(mUserControlSettingsPaths);
            InitializeUserControl(mUserControlSettingsSleepTimes);
            mUserControlLastUsed            = mUserControlSettingsSleepTimes;
            mUserControlLastUsed.IsEnabled  = true;
            mUserControlLastUsed.Visibility = Visibility.Visible;
        }

        private void InitializeUserControl(UserControl userControl)
        {
            GridSettings.Children.Add(userControl);
            userControl.VerticalAlignment   = VerticalAlignment.Top;
            userControl.Visibility          = Visibility.Hidden;
        }
        
        private void ButtonOK_Click(object sender, System.EventArgs e)
        {
            // Keep Changes
            Close();
        }

        private void ButtonCancel_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void SettingsWindow_Closed(object sender, EventArgs e)
        {
            // Discard Changes
            //if (DialogResult == null/*DialogResult.Cancel*/ && mUserControlSettingsGeneral.mOldThemeIndex != -1)
            //    ThemeManager.ApplyTheme(mUserControlSettingsGeneral.mOldThemeIndex);
        }

        private void TreeViewItemSettings_Selected(object sender, RoutedEventArgs e)
        {
            switch ((sender as TreeViewItem).Header.ToString())
            {
                case "General":
                    //SetUserControl(mUserControlSettingsGeneral);
                    break;
                case "Paths":
                    //SetUserControl(mUserControlSettingsPaths);
                    break;
                case "Client Starter":
                    SetUserControl(mUserControlSettingsSleepTimes);
                    break;
            }
        }

        private void SetUserControl(UserControl userControl)
        {
            mUserControlLastUsed.IsEnabled  = false;
            mUserControlLastUsed.Visibility = Visibility.Hidden;
            userControl.IsEnabled           = true;
            userControl.Visibility          = Visibility.Visible;
            mUserControlLastUsed            = userControl;
        }

        public string GetWLOProgramPath()
        {
            return null;//mUserControlSettingsPaths.TextBoxWLOProgramPath.Text;
        }

        public string GetWLOUpdateProgramPath()
        {
            return null;//mUserControlSettingsPaths.TextBoxWLOUpdateProgramPath.Text;
        }

        public bool GetUseWLOProgramFolderForUpdateProgram()
        {
            return false;//mUserControlSettingsPaths.CheckBoxSameFolder.IsChecked.Value;
        }

        public int GetSleepLengthShort()
        {
            return int.Parse(mUserControlSettingsSleepTimes.TextBoxShortWait.Text);
        }

        public int GetSleepLengthLong()
        {
            return int.Parse(mUserControlSettingsSleepTimes.TextBoxLongWait.Text);
        }

        public int GetTimeBeforeRetry()
        {
            return int.Parse(mUserControlSettingsSleepTimes.TextBoxTimeBeforeRetry.Text);
        }

        public int GetRetryTimes()
        {
            return int.Parse(mUserControlSettingsSleepTimes.TextBoxRetryTimes.Text);
        }

        public int GetTimeBetweenClientStarts()
        {
            return int.Parse(mUserControlSettingsSleepTimes.TextBoxWaitTimeBetweenClients.Text);
        }

        public int GetLengthFromScreenSidesH()
        {
            return int.Parse(mUserControlSettingsSleepTimes.TextBoxLengthFromScreenSidesH.Text);
        }

        public int GetLengthFromScreenSidesV()
        {
            return int.Parse(mUserControlSettingsSleepTimes.TextBoxLengthFromScreenSidesV.Text);
        }

        public bool SettingsChanged()
        {
            if (GetLengthFromScreenSidesH()                 == mLengthFromScreenSidesHOld &&
                GetLengthFromScreenSidesV()                 == mLengthFromScreenSidesVOld &&
                GetRetryTimes()                             == mRetryTimesOld &&
                GetSleepLengthLong()                        == mSleepLengthLongOld &&
                GetSleepLengthShort()                       == mSleepLengthShortOld &&
                GetTimeBeforeRetry()                        == mTimeBeforeRetryOld &&
                GetTimeBetweenClientStarts()                == mTimeBetweenClientStartsOld &&
                GetUseWLOProgramFolderForUpdateProgram()    == mUseWLOProgramFolderForUpdateProgramOld &&
                GetWLOProgramPath()                         == mWLOProgramPathOld && 
                GetWLOUpdateProgramPath()                   == mWLOUpdateProgramPathOld)// &&
                //ThemeManager.ThemeIndex                     == mThemeIndexOld)
                return false;
            else
                return true;
        }
    }
}
