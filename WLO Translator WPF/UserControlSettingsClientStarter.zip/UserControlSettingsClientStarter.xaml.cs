﻿using System;
using System.Windows.Controls;
using System.Windows.Media;

namespace WLO_Translator_WPF
{
    public partial class UserControlSettingsClientStarter : UserControl
    {
        private int             mClientsToStart                         = 1;
        private int             mSleepLengthShort                       = 1000;
        private int             mSleepLengthLong                        = 2000;
        private int             mTimeBeforeRetry                        = 6000;
        private int             mRetryTimes                             = 5;
        private int             mLengthFromScreenSidesH                 = 48;
        private int             mLengthFromScreenSidesV                 = 32;

        private string          mTextBoxShortWaitOldText                = "";
        private string          mTextBoxLongWaitOldText                 = "";
        private string          mTextBoxRetryTimesOldText               = "";
        private string          mTextBoxTimeBeforeRetryOldText          = "";
        private string          mTextBoxLenghtFromScreenSidesHOldText   = "";
        private string          mTextBoxLenghtFromScreenSidesVOldText   = "";

        public UserControlSettingsClientStarter(int sleepLengthShort, int sleepLengthLong,
                                             int timeBeforeRetry, int retryTimes, int timeBetweenClientStarts,
                                             int lengthFromScreenSidesH, int lengthFromScreenSidesV)
        {
            InitializeComponent();

            TextBoxShortWait.Text               = sleepLengthShort.ToString();
            TextBoxLongWait.Text                = sleepLengthLong.ToString();
            TextBoxRetryTimes.Text              = retryTimes.ToString();
            TextBoxTimeBeforeRetry.Text         = timeBeforeRetry.ToString();
            TextBoxWaitTimeBetweenClients.Text  = timeBetweenClientStarts.ToString();
            TextBoxLengthFromScreenSidesH.Text  = lengthFromScreenSidesH.ToString();
            TextBoxLengthFromScreenSidesV.Text  = lengthFromScreenSidesV.ToString();
        }

        private void TextBoxLengthFromScreenSidesH_Enter(object sender, EventArgs e)
        {
            mTextBoxLenghtFromScreenSidesHOldText = ((TextBox)sender).Text;
        }

        private void TextBoxLengthFromScreenSidesV_Enter(object sender, EventArgs e)
        {
            mTextBoxLenghtFromScreenSidesVOldText = ((TextBox)sender).Text;
        }

        #region TextBox Text Changes
        private void TextBoxShortWait_TextChanged(object sender, EventArgs e)
        {
            int output;
            if (int.TryParse(((TextBox)sender).Text, out output) && output != 0 && output <= 100000)
            {
                ((TextBox)sender).Background = new SolidColorBrush(System.Windows.SystemColors.WindowColor);
                mSleepLengthShort = output;
            }
            else
            {
                ((TextBox)sender).Background = new SolidColorBrush(Colors.Red);
                mSleepLengthShort = output;
            }
            
            // Save to History
            //ClientStarterHistoryManagment.SaveHistoryAction(HistoryActionTypes.TextBoxShortWait_TextChanged, mTextBoxShortWaitOldText);
        }

        private void TextBoxLongWait_TextChanged(object sender, EventArgs e)
        {
            int output;
            if (int.TryParse(((TextBox)sender).Text, out output) && output != 0 && output <= 100000)
            {
                ((TextBox)sender).Background = new SolidColorBrush(System.Windows.SystemColors.WindowColor);
                mSleepLengthLong = output;
            }
            else
            {
                ((TextBox)sender).Background = new SolidColorBrush(Colors.Red);
                mSleepLengthLong = output;
            }

            // Save to History
            //ClientStarterHistoryManagment.SaveHistoryAction(HistoryActionTypes.TextBoxLongWait_TextChanged, mTextBoxLongWaitOldText);
        }

        private void TextBoxRetryTimes_TextChanged(object sender, EventArgs e)
        {
            int output;
            if (int.TryParse(((TextBox)sender).Text, out output) && output != 0 && output <= 100000)
            {
                ((TextBox)sender).Background = new SolidColorBrush(System.Windows.SystemColors.WindowColor);
                mRetryTimes = output;
            }
            else
            {
                ((TextBox)sender).Background = new SolidColorBrush(Colors.Red);
                mRetryTimes = output;
            }

            // Save to History
            //ClientStarterHistoryManagment.SaveHistoryAction(HistoryActionTypes.TextBoxRetryTimes_TextChanged, mTextBoxRetryTimesOldText);
        }

        private void TextBoxTimeBeforeRetry_TextChanged(object sender, EventArgs e)
        {
            int output;
            if (int.TryParse(((TextBox)sender).Text, out output) && output != 0 && output <= 100000)
            {
                ((TextBox)sender).Background = new SolidColorBrush(System.Windows.SystemColors.WindowColor);
                mTimeBeforeRetry = output;
            }
            else
            {
                ((TextBox)sender).Background = new SolidColorBrush(Colors.Red);
                mTimeBeforeRetry = output;
            }

            // Save to History
            //ClientStarterHistoryManagment.SaveHistoryAction(HistoryActionTypes.TextBoxTimeBeforeRetry_TextChanged, mTextBoxTimeBeforeRetryOldText);
        }
        #endregion

        private void ButtonDefaultValues_Click(object sender, EventArgs e)
        {
            mTextBoxShortWaitOldText                = TextBoxShortWait.Text;
            mTextBoxLongWaitOldText                 = TextBoxLongWait.Text;
            mTextBoxRetryTimesOldText               = TextBoxRetryTimes.Text;
            mTextBoxTimeBeforeRetryOldText          = TextBoxTimeBeforeRetry.Text;
            mTextBoxLenghtFromScreenSidesHOldText   = TextBoxLengthFromScreenSidesH.Text;
            mTextBoxLenghtFromScreenSidesVOldText   = TextBoxLengthFromScreenSidesV.Text;

            TextBoxShortWait.Text                   = ( mSleepLengthShort        = 1000  ).ToString();
            TextBoxLongWait.Text                    = ( mSleepLengthLong         = 2000  ).ToString();
            TextBoxTimeBeforeRetry.Text             = ( mTimeBeforeRetry         = 20000 ).ToString();
            TextBoxWaitTimeBetweenClients.Text      = ( /*mTimeBetweenClientStarts = */300   ).ToString();
            TextBoxLengthFromScreenSidesH.Text      = ( mLengthFromScreenSidesH  = 48    ).ToString();
            TextBoxLengthFromScreenSidesV.Text      = ( mLengthFromScreenSidesV  = 32    ).ToString();
        }
    }
}
